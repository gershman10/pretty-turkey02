---
layout: post
title: "Satan Quotes Paradise Lost"
date: 2019-05-25
---

Here at least
We shall be free; th’ Almighty hath not built
Here for his envy, will not drive us hence:
Here we may reign secure, and in my choyce
To reign is worth ambition though in Hell:
Better to reign in Hell, then serve in Heav’n.

To waste his whole Creation, or possess
All as our own, and drive as we were driven,
The punie habitants, or if not drive,
Seduce them to our Party, that thir God
May prove thir foe, and with repenting hand
Abolish his own works. This would surpass
Common revenge, and interrupt his joy
In our Confusion, and our Joy upraise
In his disturbance; when his darling Sons
Hurl’d headlong to partake with us, shall curse
Thir frail Originals, and faded bliss,
Faded so soon.
